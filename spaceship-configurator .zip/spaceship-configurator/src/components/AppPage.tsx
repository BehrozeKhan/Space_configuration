import React, { useState } from "react";
import Grid from "@mui/material/Grid";

const AppPage = () => {
  const [activeColor, setColor] = useState(0);
  const [activePower, setPower] = useState(0);
  const [activeDrive, setDrive] = useState(0);
  const [activePackage, setPackage] = useState(0);
  let basePrice = "1000";
  let colorPrice;
  let powerPrice;
  let warpDrive;
  let plan;
  let total;
  colorPrice =
    activeColor === 1
      ? "0"
      : activeColor === 2
      ? "100"
      : activeColor === 3
      ? "100"
      : "0";
  powerPrice =
    activePower === 1
      ? "0"
      : activePower === 2
      ? "200"
      : activePower === 3
      ? "500"
      : "0";

  warpDrive = activeDrive === 1 ? "0" : activeDrive === 2 ? "1000" : "0";

  plan =
    activePackage === 1
      ? "0"
      : activePackage === 2
      ? "200"
      : activePackage === 3
      ? "500"
      : "0";

  //  total
  total =
    Number(basePrice) +
    Number(colorPrice) +
    Number(powerPrice) +
    Number(warpDrive) +
    Number(plan);
  return (
    <div className="container">
      <div className="left">
        <form>
          <h2>Select color:</h2>
          <br />
          <br />
          <Grid container spacing={2}>
            <Grid item xs={4}>
              <div
                className={activeColor === 1 ? "card-active" : "card"}
                onClick={() => setColor(1)}
              >
                <div className="card-content">
                  <div className="color1"></div>
                  <p className="price">+0€</p>
                  <h2>Snow</h2>
                </div>
              </div>
            </Grid>
            <Grid item xs={4}>
              <div
                className={activeColor === 2 ? "card-active" : "card"}
                onClick={() => setColor(2)}
              >
                <div className="card-content">
                  <div className="color2"></div>
                  <p className="price">+100€</p>
                  <h2>Volcano</h2>
                </div>
              </div>
            </Grid>
            <Grid item xs={4}>
              <div
                className={activeColor === 3 ? "card-active" : "card"}
                onClick={() => setColor(3)}
              >
                <div className="card-content">
                  <div className="color3"></div>
                  <p className="price">+100€</p>
                  <h2>Sky</h2>
                </div>
              </div>
            </Grid>
          </Grid>
        </form>
        <br />
        <form>
          <h2>Select power:</h2>
          <br />
          <br />
          <Grid container spacing={2}>
            <Grid item xs={4}>
              <div
                className={activePower === 1 ? "card-active" : "card"}
                onClick={() => setPower(1)}
              >
                <div className="card-content">
                  <h2>100 MW</h2>
                  <p className="price">+0€</p>
                </div>
              </div>
            </Grid>
            <Grid item xs={4}>
              <div
                className={activePower === 2 ? "card-active" : "card"}
                onClick={() => setPower(2)}
              >
                <div className="card-content">
                  <h2>150 MW</h2>
                  <p className="price">+200€</p>
                </div>
              </div>
            </Grid>
            <Grid item xs={4}>
              <div
                className={activePower === 3 ? "card-active" : "card"}
                onClick={() => setPower(3)}
              >
                <div className="card-content">
                  <h2>200 MW</h2>
                  <p className="price">+500€</p>
                </div>
              </div>
            </Grid>
          </Grid>
        </form>
        <br />
        <form>
          <h2>Warp drive:</h2>
          <br />
          <br />
          <Grid container spacing={2}>
            <Grid item xs={4}>
              <div
                className={activeDrive === 1 ? "card-active" : "card"}
                onClick={() => setDrive(1)}
              >
                <div className="card-content">
                  <h2>NO</h2>
                  <p className="price">+0€</p>
                </div>
              </div>
            </Grid>
            <Grid item xs={4}>
              <div
                className={activeDrive === 2 ? "card-active" : "card"}
                onClick={() => setDrive(2)}
              >
                <div className="card-content">
                  <h2>YES</h2>
                  <p className="price">+1000€</p>
                </div>
              </div>
            </Grid>
          </Grid>
        </form>
        <br />
        <form>
          <h2>Select option package:</h2>
          <br />
          <br />
          <Grid container spacing={2}>
            <Grid item xs={4}>
              <div
                className={activePackage === 1 ? "card-active" : "card"}
                onClick={() => setPackage(1)}
              >
                <div className="top">
                  <h2>Basic</h2>
                  <p className="price">+0€</p>
                </div>
                <div className="plans">
                  <ul style={{ listStyle: "none" }}>
                    <li><i className="fa fa-caret-up" aria-hidden="true"></i> Air Conditioning</li>
                    <li><i className="fa fa-caret-up" aria-hidden="true"></i> Cloth seats</li>
                    <li><i className="fa fa-caret-up" aria-hidden="true"></i> Fm radio</li>
                  </ul>
                </div>
              </div>
            </Grid>
            <Grid item xs={4}>
              <div
                className={activePackage === 2 ? "card-active" : "card"}
                onClick={() => setPackage(2)}
              >
                <div className="top">
                  <h2>Sport</h2>
                  <p className="price">+200€</p>
                </div>
                <div className="plans">
                  <ul style={{ listStyle: "none" }}>
                    <li><i className="fa fa-caret-up" aria-hidden="true"></i> Air Conditioning</li>
                    <li><i className="fa fa-caret-up" aria-hidden="true"></i> Cloth seats</li>
                    <li><i className="fa fa-caret-up" aria-hidden="true"></i> Fm radio</li>
                    <li><i className="fa fa-caret-up" aria-hidden="true"></i> personal tech support</li>
                  </ul>
                </div>
              </div>
            </Grid>
            <Grid item xs={4}>
              <div
                className={activePackage === 3 ? "card-active" : "card"}
                onClick={() => setPackage(3)}
              >
                <div className="top">
                  <h2>Lux</h2>
                  <p className="price">+500€</p>
                </div>
                <div className="plans">
                  <ul style={{ listStyle: "none" }}>
                    <li><i className="fa fa-caret-up" aria-hidden="true"></i> Air Conditioning</li>
                    <li><i className="fa fa-caret-up" aria-hidden="true"></i> Luxury seats</li>
                    <li><i className="fa fa-caret-up" aria-hidden="true"></i> Fm radio</li>
                    <li><i className="fa fa-caret-up" aria-hidden="true"></i> Chrome weels</li>
                    <li><i className="fa fa-caret-up" aria-hidden="true"></i> Window tint</li>
                    <li><i className="fa fa-caret-up" aria-hidden="true"></i> Subwoofer</li>
                  </ul>
                </div>
              </div>
            </Grid>
          </Grid>
        </form>
      </div>
      {/*//////////////////////////////////////////////////////////Right////////////////////////////////////////////////////////////// */}
      <div className="right">
        <div
          className="card"
          style={{
            paddingRight: "20px",
            backgroundColor: "#1c3c16",
            border: "2px solid #346c2b",
          }}
        >
          <div className="card-content">
            <div className="bill-list">
              <p className="cart-list">Base price</p>
              <p className="cart-price">+{basePrice}€</p>
            </div>
            <div className="bill-list">
              <p className="cart-list">color</p>
              <p className="cart-price">+{colorPrice}€</p>
            </div>
            <div className="bill-list">
              <p className="cart-list">Power</p>
              <p className="cart-price">+{powerPrice}€</p>
            </div>
            <div className="bill-list">
              <p className="cart-list">Warp drive</p>
              <p className="cart-price">+{warpDrive}€</p>
            </div>
            <div className="bill-list">
              <p className="cart-list">Option package</p>
              <p className="cart-price">+{plan}€</p>
            </div>
            <hr style={{ marginTop: "40px" }}></hr>
            <div className="bill-list">
              <h2 className="cart-list">Total</h2>
              <h2 className="cart-price">+ {total}€</h2>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AppPage;
